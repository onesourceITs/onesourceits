# write hello world script
# variables
# store loop controller
controller  = 0

# messages
msg = ["Let\'s say...", "Hello World!"]

# loop to run while num is less than 2
while controller < 2:
    print(msg[controller])
    controller +=1
    