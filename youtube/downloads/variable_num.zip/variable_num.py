# Python 3 Variables and Numbers
# variable components
# var_name = var_value

user_name = "Johnny"
print(user_name)

# brief intro to numbers
#print(2+2)
#print(2-2)
#print(2*2)
#print(2//2)
#print(2**16)
