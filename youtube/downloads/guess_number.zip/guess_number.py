# guess the number game 
# basic version of the game we will build at the end of the series

# import the random number module
import random

# welcome messages and collect name
print("Welcome to the Guess the Number Game!")
print("What is your name?")
user_name = input()

# start the game

# store random num
winning_num = random.randint(1, 50)

# store the amount of allowed guesses
guesses_allowed = 8
print("Ok "+user_name+", you have ",guesses_allowed," guesses and number will be a possibility of 1 to 50. \n Good Luck!")

# guesses the user has used
#will control the loop
guesses_taken = 0

# now start the loop 
# as long as guesses_taken dont equal guess_allowed
while guesses_taken != guesses_allowed:
    user_input = int(input("Take a Guess!"))
    
    # conditions based off the user input
    if user_input > winning_num:
        print("Your guess was to high!")
    elif user_input < winning_num:
        print("Your guess was to low!")
    else:
        print("Congrats! You guessed the correct number.")
        break

    # add one to the guesses_taken
    guesses_taken +=1    

if guesses_taken == guesses_allowed:
    print("Sorry "+user_name+". You did not guess the correct number.")
    print("\nThe winning number was ",winning_num,".")
